#include <bits/stdc++.h>
using namespace std;

int spanningTree(int V, vector<vector<int>> &adj)
{
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;

    // Vector to keep track of the minimum weights
    vector<int> key(V, INT_MAX);

    vector<bool> inMST(V, false);

    // Starting from node 0
    pq.push({0, 0});
    key[0] = 0;

    int sum = 0;

    while (!pq.empty())
    {
        int u = pq.top().second;
        pq.pop();

        if (inMST[u])
            continue;

        inMST[u] = true;
        sum += key[u];

        for (int v = 0; v < V; ++v)
        {
            if (adj[u][v] && !inMST[v] && adj[u][v] < key[v])
            {
                key[v] = adj[u][v];
                pq.push({key[v], v});
            }
        }
    }

    return sum;
}

int main()
{
    int n;
    cin >> n;
    vector<vector<int>> adj(n, vector<int>(n));

    for (int i = 0; i < n; ++i)
        for (int j = 0; j < n; ++j)
            cin >> adj[i][j];

    int ans = spanningTree(n, adj);
    cout << "Sum of weights of edges of the Minimum Spanning Tree: " << ans << endl;
    return 0;
}
