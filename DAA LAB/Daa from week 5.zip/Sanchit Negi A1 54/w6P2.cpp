#include <bits/stdc++.h>
using namespace std;

bool bfs(int src, vector<vector<int>> adj, vector<int> &visited)
{
    queue<int> q;
    q.push(0);
    visited[0] = 1;
    int color = 0;

    while (!q.empty())
    {
        int node = q.front();
        q.pop();

        if (adj[node][node] == 1) // self loop
            return false;

        for (int i = 0; i < adj[node].size(); i++)
        {
            if (visited[i] == color)
                return false;
            else if (visited[i] == -1 && adj[node][i])
            {
                visited[i] = color;
            }
        }
        color ^= 1;
    }
    return true;
}

int main()
{
    int n;
    cin >> n;
    vector<vector<int>> adj(n, vector<int>(n));

    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            cin >> adj[i][j];

    vector<int> visited(n, -1);

    if (bfs(0, adj, visited))
    {
        cout << "Graph is bipartite\n";
    }
    else
    {
        cout << "Graph is not bipartite\n";
    }

    return 0;
}