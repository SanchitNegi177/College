#include <bits/stdc++.h>

using namespace std;

int matrixChainMemoised(vector<int> &p, int i, int j, vector<vector<int>> &dp)
{
    if (i == j)
    {
        return 0;
    }
    if (dp[i][j] != -1)
    {
        return dp[i][j];
    }
    dp[i][j] = INT_MAX;
    for (int k = i; k < j; k++)
    {
        dp[i][j] = min(dp[i][j], (matrixChainMemoised(p, i, k, dp) + matrixChainMemoised(p, k + 1, j, dp) + p[i - 1] * p[k] * p[j]));
    }
    return dp[i][j];
}

int matrixChainOrder(vector<int> &p)
{
    int n = p.size();
    vector<vector<int>> dp(n, vector<int>(n, -1));
    return matrixChainMemoised(p, 1, n - 1, dp);
}

int main()
{
    int n ;cin>>n;
    vector<int>v(n);
    for(auto &it:v) cin>>it;

    cout << "Minimum number of multiplications is " << matrixChainOrder(v) << endl;
    return 0;
}
